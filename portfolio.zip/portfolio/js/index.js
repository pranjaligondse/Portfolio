$(function(){
    var element_position = $('#techskill').offset().top;
    $(window).on('scroll', function() {
        var y_scroll_pos = window.pageYOffset;
        var scroll_pos_test = element_position - 400;
        if(y_scroll_pos > scroll_pos_test) {
            $("#sklhtml").animate({ marginLeft: '85%',width:'15%'},1500).append("<div class='caption'>85%</div>"); 
            $("#sklcss").animate({ marginLeft: '80%',width:'20%'},1500).append("<div class='caption'>80%</div>"); 
            $("#sklboot").animate({ marginLeft: '80%',width:'20%'},1500).append("<div class='caption'>80%</div>"); 
            $("#skljq").animate({ marginLeft: '50%',width:'50%'},1500).append("<div class='caption'>50%</div>"); 
             
        }
    });    
})
window.onscroll=function(){myFunction()};
var navbar=document.getElementById("navbar");
var sticky=navbar.offstTop;
function myFunction(){
    if(window.pageYOffset >=sticky){
        navbar.classList.add("sticky")
    } else{
        navbar.classList.remove("sticky");
    }
}